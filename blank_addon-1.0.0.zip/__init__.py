import bpy

import bpy
from bpy.types import Panel

class Blank_PT_Addon(Panel):
  """Display test button"""
  bl_label = ""
  bl_space_type = "VIEW_3D"
  bl_region_type = "UI"
  bl_category = "Minimize"
  bl_options = {'HIDE_HEADER'}
  bl_order = 0

  def draw(self, context):
    pass

def register():
  bpy.utils.register_class(Blank_PT_Addon)
       
def unregister():
  bpy.utils.unregister_class(Blank_PT_Addon)

if __name__ == '__main__':
    register()